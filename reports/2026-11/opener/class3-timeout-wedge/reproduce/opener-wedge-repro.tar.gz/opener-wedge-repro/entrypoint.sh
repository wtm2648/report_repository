#!/bin/sh
# 启动 OpENer master：自动探测默认路由网卡（bridge 模式下为 eth0）。
set -eu

IFACE="${OPENER_IFACE:-}"
if [ -z "$IFACE" ]; then
    IFACE=$(ip -4 route show default 2>/dev/null \
        | awk '{for (i = 1; i <= NF; i++) if ($i == "dev") { print $(i + 1); exit }}')
fi
[ -n "$IFACE" ] || IFACE=eth0

exec /usr/local/src/build-opener/src/ports/POSIX/OpENer "$IFACE"
