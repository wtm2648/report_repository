#!/usr/bin/env python3
"""健康检查：向本地 OpENer 发送 EtherNet/IP ListIdentity（UDP 44818），并检查 TCP 44818。"""
import socket
import struct
import sys

PORT = 44818


def local_ip() -> str:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    finally:
        sock.close()


def main() -> int:
    ip = local_ip()

    # ListIdentity 封装头（24 字节）：命令 0x0063，其余字段清零
    request = struct.pack("<HHII8sI", 0x0063, 0, 0, 0, b"\x00" * 8, 0)
    udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp.settimeout(3)
    try:
        udp.sendto(request, (ip, PORT))
        reply, _ = udp.recvfrom(2048)
    except OSError:
        reply = b""
    finally:
        udp.close()

    if len(reply) < 24 or reply[:2] != b"\x63\x00":
        return 1

    try:
        socket.create_connection((ip, PORT), timeout=3).close()
    except OSError:
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
