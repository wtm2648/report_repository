#!/usr/bin/env python3
"""OpENer master：Class 3 超时无效 socket(-1) → RemoveSocketTimerFromList 死循环 复现脚本。

序列（每 trial 前重启容器，保证 session handle=1 与干净状态）：
  1. TCP 连接 127.0.0.1:44819（映射到容器 44818）
  2. 发 bullets/1-register.msg        —— RegisterSession（session handle=1）
  3. 发 bullets/2-fwdopen-1.msg        —— ForwardOpen #1
  4. 发 bullets/3-fwdopen-2.msg        —— ForwardOpen #2
  5. 发 bullets/4-sendunit-declared100-actual30.msg
     （SendUnitData，封装头声明 Length=100，实际帧体 30 字节）
  6. 5 秒后断开连接，观察最长 120 秒：
     - CPU 自旋（/proc utime+stime 3 秒窗口 ticks）+ TCP 探测失败 → WEDGE
       → docker exec gdb 附加抓全线程栈存 results/
     - 进程退出/容器重启计数变化 → CRASH-EXIT
用法： python3 repro.py [--trials N] [--keep-going]
默认 10 个 trial，首个确认 WEDGE（含 gdb 栈）后停止。
"""
import argparse
import json
import pathlib
import socket
import subprocess
import sys
import time
import datetime

WS = pathlib.Path(__file__).resolve().parent
BULLETS = WS / "bullets"
RESULTS = WS / "results"
CONTAINER = "proto-opener-master"
HOST, PORT = "127.0.0.1", 44819
WAIT_S = 120            # 观察 Class 3 超时引爆的窗口（v2.3 实测 ~50-59s，放宽余量）
QUIET_S = 5             # killer 帧后静默时长，再断开
CPU_THRESH_TICKS = 240  # 3 秒采样窗口内 utime+stime ≥240 ticks ≈ 80%+ CPU


def sh(cmd, timeout=90):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)


def log(msg):
    line = f"[{datetime.datetime.now().strftime('%H:%M:%S')}] {msg}"
    print(line, flush=True)
    with open(RESULTS / "repro-run.log", "a") as f:
        f.write(line + "\n")


def restart_and_wait_healthy():
    sh(f"docker restart {CONTAINER}")
    for _ in range(40):
        time.sleep(2)
        h = sh(f"docker inspect --format '{{{{.State.Health.Status}}}}' {CONTAINER}").stdout.strip()
        if h == "healthy":
            return True
    return False


def restarts():
    r = sh(f"docker inspect --format '{{{{.RestartCount}}}}' {CONTAINER}").stdout.strip()
    return int(r) if r.isdigit() else -1


def send_and_drain(sock: socket.socket, data: bytes, expect_reply=True, timeout=3.0):
    sock.sendall(data)
    sock.settimeout(timeout)
    buf = b""
    try:
        while True:
            chunk = sock.recv(4096)
            if not chunk:
                return buf, True   # peer closed
            buf += chunk
            if not expect_reply or len(buf) >= 24:
                return buf, False
    except socket.timeout:
        return buf, False


def opener_pid():
    out = sh(f"docker exec {CONTAINER} sh -c 'pidof OpENer'").stdout.strip()
    return out.split()[0] if out else None


def cpu_ticks_3s():
    """返回 3 秒窗口内 OpENer 主进程 utime+stime 增量（ticks），进程消失返回 'PROC-GONE'。"""
    p1 = opener_pid()
    if not p1:
        return "PROC-GONE"
    s1 = sh(f"docker exec {CONTAINER} sh -c 'cat /proc/{p1}/stat'").stdout
    try:
        u1 = int(s1.split()[13]) + int(s1.split()[14])
    except (IndexError, ValueError):
        return "PROC-GONE"
    time.sleep(3)
    p2 = opener_pid()
    if not p2 or p2 != p1:
        return "PROC-GONE"
    s2 = sh(f"docker exec {CONTAINER} sh -c 'cat /proc/{p2}/stat'").stdout
    try:
        u2 = int(s2.split()[13]) + int(s2.split()[14])
    except (IndexError, ValueError):
        return "PROC-GONE"
    return u2 - u1


def probe_alive(timeout=2.0):
    """用容器内 opener-probe 判活：UDP ListIdentity 必须由事件循环应答，
    不受内核 TCP accept backlog 假阳性影响（楔死时 connect 仍可能握手成功）。"""
    r = sh(f"docker exec {CONTAINER} python3 /usr/local/bin/opener-probe",
           timeout=timeout + 8)
    return r.returncode == 0


def capture_wedge_evidence(trial):
    ts = datetime.datetime.now().strftime("%H%M%S")
    bt = RESULTS / f"wedge-bt-trial{trial}-{ts}.txt"
    r = sh(f"docker exec {CONTAINER} sh -c "
           f"'timeout 40 gdb -p $(pidof OpENer) -batch -ex \"thread apply all bt\"'", timeout=60)
    bt.write_text(r.stdout + r.stderr)
    proc = RESULTS / f"wedge-proc-trial{trial}-{ts}.txt"
    proc.write_text(sh(f"docker exec {CONTAINER} sh -c "
                       f"'cat /proc/$(pidof OpENer)/status; echo ---; ps aux'").stdout)
    dl = RESULTS / f"docker-logs-trial{trial}-{ts}.txt"
    dl.write_text(sh(f"docker logs --tail 200 {CONTAINER}").stdout)
    log(f"证据已存: {bt.name}, {proc.name}, {dl.name}")
    return bt


def run_trial(trial):
    rec = {"trial": trial, "ts": datetime.datetime.now().isoformat(timespec="seconds"),
           "verdict": "NO-REPRO"}
    if not restart_and_wait_healthy():
        rec["verdict"] = "ENV-ERROR"
        return rec
    rec["restart_base"] = restarts()

    frames = {p.name: p.read_bytes() for p in sorted(BULLETS.glob("*.msg"))}
    try:
        s = socket.create_connection((HOST, PORT), timeout=3)
        r0, _ = send_and_drain(s, frames["1-register.msg"])
        r1, _ = send_and_drain(s, frames["2-fwdopen-1.msg"])
        r2, _ = send_and_drain(s, frames["3-fwdopen-2.msg"])
        rec["setup_replies"] = [len(r0), len(r1), len(r2)]
        if len(r1) < 24 or len(r2) < 24:
            rec["verdict"] = "SETUP-FAILED"
            s.close()
            return rec
        killer = frames["4-sendunit-declared100-actual30.msg"]
        rec["killer_bytes"] = len(killer)
        s.sendall(killer)          # 不等回复（声明 100 实发 30，服务器按声明继续等字节）
        time.sleep(QUIET_S)
        s.close()                  # 模拟客户端断开
    except OSError as e:
        rec["setup_error"] = str(e)
        return rec

    t0 = time.time()
    max_cpu = 0
    while time.time() - t0 < WAIT_S:
        if restarts() != rec["restart_base"]:
            rec["verdict"] = "CRASH-EXIT"
            rec["time_to"] = round(time.time() - t0, 1)
            break
        c = cpu_ticks_3s()
        if c == "PROC-GONE":
            time.sleep(2)
            if restarts() != rec["restart_base"]:
                rec["verdict"] = "CRASH-EXIT"
                rec["time_to"] = round(time.time() - t0, 1)
            break
        if isinstance(c, int):
            max_cpu = max(max_cpu, c)
            if c >= CPU_THRESH_TICKS and not probe_alive(2.0):
                rec["verdict"] = "WEDGE"
                rec["time_to"] = round(time.time() - t0, 1)
                rec["max_cpu_ticks_3s"] = max_cpu
                rec["bt_file"] = capture_wedge_evidence(trial).name
                sh(f"docker restart {CONTAINER}")   # 解困，供后续 trial
                break
    rec.setdefault("max_cpu_ticks_3s", max_cpu)
    rec["elapsed"] = round(time.time() - t0, 1)
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trials", type=int, default=10)
    ap.add_argument("--keep-going", action="store_true",
                    help="即使已确认 WEDGE 也跑完全部 trial（统计复现率）")
    args = ap.parse_args()

    RESULTS.mkdir(exist_ok=True)
    log(f"=== 复现开始：trials={args.trials} target={CONTAINER}({HOST}:{PORT}) ===")
    wedges = 0
    with open(RESULTS / "repro-log.jsonl", "a") as out:
        for i in range(1, args.trials + 1):
            rec = run_trial(i)
            if rec["verdict"] == "WEDGE":
                wedges += 1
            out.write(json.dumps(rec, ensure_ascii=False) + "\n")
            out.flush()
            log(f"trial {i}: {rec['verdict']}"
                + (f" @ {rec.get('time_to')}s" if rec.get("time_to") else "")
                + (f" cpu={rec.get('max_cpu_ticks_3s')}" if isinstance(rec.get("max_cpu_ticks_3s"), int) else ""))
            if wedges and not args.keep_going:
                break
    log(f"=== 结束：{wedges} 次确认 WEDGE（含 gdb 栈）===")
    return 0 if wedges else 1


if __name__ == "__main__":
    sys.exit(main())
