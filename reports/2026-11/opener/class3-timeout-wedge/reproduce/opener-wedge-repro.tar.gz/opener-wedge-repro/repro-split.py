#!/usr/bin/env python3
"""分片到达变体：REGISTER → ForwardOpen×2 → 完全合法的 SendUnitData（声明30=实际30）
拆成两次 write（先24B头，隔1s，再30B体）→ 断开 → 等待超时。零畸形字节。
用法： python3 repro-split.py [--trials N]（默认 3，每 trial 抓 gdb 栈）"""
import argparse, datetime, json, pathlib, socket, subprocess, time
WS = pathlib.Path(__file__).resolve().parent
BULLETS, RESULTS = WS / "bullets", WS / "results"
CONTAINER, HOST, PORT = "proto-opener-master", "127.0.0.1", 44819

def sh(cmd, timeout=90):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)

def restart_and_wait():
    sh(f"docker restart {CONTAINER}")
    for _ in range(40):
        time.sleep(2)
        if sh(f"docker inspect --format '{{{{.State.Health.Status}}}}' {CONTAINER}").stdout.strip() == "healthy":
            return True
    return False

def run_trial(i):
    rec = {"trial": i, "ts": datetime.datetime.now().isoformat(timespec="seconds"), "variant": "legal-split-delivery"}
    if not restart_and_wait():
        rec["verdict"] = "ENV-ERROR"; return rec
    frames = [(BULLETS / n).read_bytes() for n in ["1-register.msg", "2-fwdopen-1.msg", "3-fwdopen-2.msg"]]
    seed = (BULLETS / "6-sendunit-seed-legal.msg").read_bytes()
    s = socket.create_connection((HOST, PORT), timeout=3)
    for f in frames:
        s.sendall(f); s.settimeout(3)
        try: s.recv(4096)
        except socket.timeout: pass
    s.sendall(seed[:24])   # 先发封装头
    time.sleep(1)          # 间隔——模拟分段到达 / 分两次 write 的客户端
    try: s.sendall(seed[24:])
    except OSError: pass   # 服务器可能已因分片丢弃关闭连接
    time.sleep(2)
    s.close()
    t0 = time.time(); cpu0 = int(sh(f"docker exec {CONTAINER} sh -c 'cat /proc/$(pidof OpENer)/stat'").stdout.split()[13])
    while time.time() - t0 < 60:
        time.sleep(3)
        r = sh(f"docker exec {CONTAINER} sh -c 'cat /proc/$(pidof OpENer)/stat'")
        if not r.stdout.strip(): rec["verdict"] = "PROC-GONE"; break
        f = r.stdout.split()
        cpu = int(f[13]) + int(f[14])
        if cpu - cpu0 >= 240 and sh(f"docker exec {CONTAINER} python3 /usr/local/bin/opener-probe").returncode != 0:
            rec.update(verdict="WEDGE", time_to=round(time.time() - t0, 1))
            ts = datetime.datetime.now().strftime("%H%M%S")
            bt = RESULTS / f"wedge-bt-split-trial{i}-{ts}.txt"
            bt.write_text(sh(f"docker exec {CONTAINER} sh -c 'timeout 40 gdb -p $(pidof OpENer) -batch "
                             f"-ex \"thread apply all bt\"'", timeout=60).stdout)
            rec["bt_file"] = bt.name
            sh(f"docker restart {CONTAINER}")
            break
    rec.setdefault("verdict", "NO-REPRO")
    return rec

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--trials", type=int, default=3)
    args = ap.parse_args()
    with open(RESULTS / "repro-split-log.jsonl", "a") as out:
        for i in range(1, args.trials + 1):
            rec = run_trial(i); out.write(json.dumps(rec, ensure_ascii=False) + "\n"); out.flush()
            print(rec, flush=True)
