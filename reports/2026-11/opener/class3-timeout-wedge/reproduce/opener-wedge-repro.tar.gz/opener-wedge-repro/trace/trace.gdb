set pagination off
set confirm off
set breakpoint pending on

watch g_registered_sessions[0]
commands
  silent
  printf "\n=== g_registered_sessions[0] -> %d ===\n", g_registered_sessions[0]
  bt 14
  continue
end

watch explicit_connection_object_pool[0].associated_encapsulation_session
commands
  silent
  printf "\n=== pool[0].associated_encapsulation_session -> %u ===\n", explicit_connection_object_pool[0].associated_encapsulation_session
  bt 14
  continue
end

watch explicit_connection_object_pool[1].associated_encapsulation_session
commands
  silent
  printf "\n=== pool[1].associated_encapsulation_session -> %u ===\n", explicit_connection_object_pool[1].associated_encapsulation_session
  bt 14
  continue
end

watch explicit_connection_object_pool[0].state
commands
  silent
  printf "\n=== pool[0].state -> %d ===\n", explicit_connection_object_pool[0].state
  bt 14
  continue
end

continue
